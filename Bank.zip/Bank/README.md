# MY BANK - Internal Frontend

Proyecto académico para el curso **Desarrollo de Aplicaciones Empresariales**.

1. Login:
2. Autenticación
