System.register(['./components/header-bar.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    return {
        setters:[
            function (header_bar_component_1_1) {
                exports_1({
                    "HeaderBarComponent": header_bar_component_1_1["HeaderBarComponent"]
                });
            }],
        execute: function() {
        }
    }
});
//# sourceMappingURL=index.js.map