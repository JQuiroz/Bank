import { Component }          from 'angular2/core';
import { RouteConfig, ROUTER_DIRECTIVES, ROUTER_PROVIDERS} from 'angular2/router';
import { LoginFormComponent } from './login/index';
import { HomeFormComponent }  from './admin/index';
import { ProductComponent }   from './product/index';

@Component({
    selector  : 'mbk-app',
    template  : `<router-outlet></router-outlet>`,
    //template: `<mbk-product></mbk-product>`
    directives: [ROUTER_DIRECTIVES]
})
@RouteConfig([
    { path  : '/login', name: 'Login', component: LoginFormComponent, useAsDefault: true },
    //{ path: '/login', name: 'login', component: LoginFormComponent},
    { path  : '/home/:id', name: 'Home', component: HomeFormComponent },
    //{ path: '/products', name: 'Productos', component: ProductComponent, useAsDefault:true}
    { path  : '/products', name: 'Productos', component: ProductComponent }
])
export class AppComponent {
    title = 'My Bank';
}
