import { Component }          from 'angular2/core';
import { FirebaseService }    from 'ng2-firebase/core';
import {Router, ROUTER_DIRECTIVES, ROUTER_PROVIDERS, RouteConfig, RouteParams} from
'angular2/router';
import { ExecutiveUserModel } from '../../executive-user/index';
import { HomeFormComponent }  from '../../admin/index';

@Component({
    selector     : 'mbk-loginform',
    templateUrl  : 'app/login/components/login-form.component.html',

})
export class LoginFormComponent {
    constructor(private routerNavigation: Router) { }

    credentials = { email: '', password: ''};

    loggingInUser(email, password) {
        var _this = this;
        var dataref = new Firebase("https://mybankapp.firebaseio.com/");
      //  var dataref = new Firebase("https://torrid-heat-7366.firebaseio.com/");
        var user;
        dataref.authWithPassword({
            email, password
        }, function(error, authData) {
            if (error) {
                alert("Usuario y password incorrecto");
            } else {
                console.log("Authenticated successfully");
                user = {
                       name: email,
                       email: email,
                       token: authData.token
                   };
                dataref.child(authData.uid).once('value', function(snapshot) {
                     if (snapshot.exists()) {
                         snapshot.ref().update(user);
                     } else {
                         var payload = {};
                         payload[authData.uid] = user;
                         snapshot.ref().parent().update(payload);
                     }
                 });
                var p = new RouteParams({id: authData.uid, name:email, email:email,avatar:'https://secure.gravatar.com/avatar/0617ecd178b4f2d159070705bdce6764?d=retro',token:authData.token});
                console.log(_this);

                _this.routerNavigation.navigate(['Home', { id: authData.uid, name: email, email: email, avatar: 'https://secure.gravatar.com/avatar/0617ecd178b4f2d159070705bdce6764?d=retro', token: authData.token }]);


            };
        }, {
            remember: "none"
        });

          }
}
