System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ExecutiveUserModel;
    return {
        setters:[],
        execute: function() {
            ExecutiveUserModel = (function () {
                function ExecutiveUserModel() {
                }
                return ExecutiveUserModel;
            }());
            exports_1("ExecutiveUserModel", ExecutiveUserModel);
        }
    }
});
//# sourceMappingURL=executive-user.model.js.map