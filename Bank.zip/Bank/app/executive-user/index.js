System.register(['./models/executive-user.model'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    return {
        setters:[
            function (executive_user_model_1_1) {
                exports_1({
                    "ExecutiveUserModel": executive_user_model_1_1["ExecutiveUserModel"]
                });
            }],
        execute: function() {
        }
    }
});
//# sourceMappingURL=index.js.map