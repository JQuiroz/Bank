export class ProductModel {
    constructor(
    public nombre: string,
    public tipo: string,
    public saldo: Number
    ) { }
}
