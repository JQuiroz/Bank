export class ClientModel {
    constructor(
		public NombreCompleto: string,
		public tipoDocumento: string,
		public NumeroDocumento: number
    ) { }
}
